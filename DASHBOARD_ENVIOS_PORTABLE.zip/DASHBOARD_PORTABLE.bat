@echo off
setlocal
cd /d "%~dp0"

title Dashboard Envios - modo portable
echo.
echo Dashboard Envios - modo portable
echo Carpeta: %CD%
echo.
echo Este modo abre el dashboard y vigila ENVIOS ARCHIVO GENERAL.xlsm.
echo Cuando guardes cambios en Excel, se regenerara dashboard.html automaticamente.
echo Para salir, cierra esta ventana.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0dashboard_portable.ps1"
if errorlevel 1 (
  echo.
  echo No se pudo iniciar el modo portable. Revisa el mensaje anterior.
  pause
  exit /b 1
)

exit /b 0
